import dao.BookingDaoInterface;
import dao.ClientDaoInterface;
import dao.TourDaoInterface;
import model.Offer;
import model.Tour;

import javax.ejb.EJB;
import java.util.List;
import java.util.Scanner;

public class Main 
{

    @EJB(mappedName = "dao.TourDaoInterface")
    private static TourDaoInterface tourDaoInterface;

    @EJB(mappedName = "dao.ClientDaoInterface")
    private static ClientDaoInterface clientDaoInterface;
    
    @EJB(mappedName = "dao.PayDaoInterface")
    private static PayDaoInterface payDaoInterface;

    public static void main(String[] args) 
    {
        List<Tour> tours = tourDaoInterface.getAllTours();
        print(tours);
        System.out.print("Enter tour type:");
        String type = scanner.nextLine();
        List<Tour> tours = tourDaoInterface.getAllLastMinuteTours(type);
        print(tours);
        System.out.print("Enter client id:");
        int id = Integer.parseInt(scanner.nextLine());
        List<Offer> offers = clientDaoInterface.getClientInfo(id);
        print(offers);
        System.out.print("Enter tour id:");
        int tourId = Integer.parseInt(scanner.nextLine());
        System.out.print("Enter client id:");
        int clientId = Integer.parseInt(scanner.nextLine());
        payDaoInterface.payTour(clientId, tourId, nOffers, discount);
    }
    
    private static <T> void print(List<T> list)
    {
        for(T val :  list)
        {
            System.out.println(val.toString()+"\n");
        }
    }
}
