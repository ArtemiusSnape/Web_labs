package dao;

import model.*;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import exceptions.DAOException;
@Stateless
public class BookingDao implements BookingDaoInterface 
{

    @PersistenceContext(unitName = "TestLocal")
    private EntityManager entityManager;


    public BookingDao(EntityManagerFactory emf) 
    {
        entityManager = emf.createEntityManager();
    }
    
    public void payTour(int clientId, int tourId, int minAmountOfOffers, double discount)
    {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Long> cq = cb.createQuery(Long.class);
        Root<Offer> offerRoot = cq.from(Offer.class);
        cq.select(cb.count(offerRoot)).where(cb.equal(offerRoot.get(Offer_.client).get("clientId"), clientId), cb.equal(offerRoot.get(Offer_.isPaid), true));
        long n_offers = entityManager.createQuery(cq).getSingleResult();

        CriteriaQuery<Tour> tourCriteriaQuery = cb.createQuery(Tour.class);
        Root<Tour> tourRoot = tourCriteriaQuery.from(Tour.class);
        tourCriteriaQuery.select(tourRoot).where(cb.equal(tourRoot.get(Tour_.tourId), tourId));
        Tour tour = entityManager.createQuery(tourCriteriaQuery).getSingleResult();

        double finalPrice = tour.getTourPrice();

        if (n_offers > minAmount)
        {
            finalPrice = finalPrice - finalPrice*discountValue/100;
        }
        
        Offer offer = new Offer(tour, client, false, finalPrice);
        entityManager.getTransaction().begin();
        entityManager.persist(offer);
        entityManager.getTransaction().commit();
        
        CriteriaQuery<Client> clientCriteriaQuery  = cb.createQuery(Client.class);
        Root<Client> clientRoot = clientCriteriaQuery.from(Client.class);
        clientCriteriaQuery.select(clientRoot).where(cb.equal(clientRoot.get(Client_.clientId), clientId));
        Client client = entityManager.createQuery(clientCriteriaQuery).getSingleResult();
    }
}
