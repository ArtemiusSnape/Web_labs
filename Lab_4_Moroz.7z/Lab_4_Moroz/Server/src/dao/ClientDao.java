package dao;

import model.Offer;
import model.Offer_;
import exceptions.DAOException;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import java.util.List;

@Stateless
public class ClientDao implements ClientDaoInterface 
{

    @PersistenceContext(unitName = "Test_Local")
    private EntityManager entityManager;

    private static Logger logger = LogManager.getLogger("logger");
    public ClientDao(EntityManagerFactory emf) 
    {
        entityManager = emf.createEntityManager();

    }

    public List<Offer> getClientInfo(int id)  throws DAOException
    {
    try {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Offer> cq = cb.createQuery(Offer.class);
        Root<Offer> offerRoot = cq.from(Offer.class);
        cq.select(offerRoot);
        cq.where(cb.equal(offerRoot.get(Offer_.client).get("clientId"), id));
        List<Offer> result = entityManager.createQuery(cq).getResultList();
    }
    catch (DAOException e) {
        logger.error("Error with client");
        throw new DAOException("ERROR! Don't found clients!");
    }
        return result;
    }
}
