package dao;

import model.Tour;
import model.Tour_;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import exceptions.DAOException;
@Stateless
public class TourDao implements TourDaoInterface 
{

    @PersistenceContext(unitName = "Test_Local")
    private EntityManager entityManager;
    private static Logger logger = LogManager.getLogger("logger");
    public TourDao(EntityManagerFactory emf) 
    {
        entityManager = emf.createEntityManager();
    }

    public List<Tour> getAllTours() throws DAOException
    {
        try{
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Tour> cq = cb.createQuery(Tour.class);
        Root<Tour> tourRoot = cq.from(Tour.class);
        cq.select(tourRoot);
        List<Tour> result = entityManager.createQuery(cq).getResultList();
        }
        catch (DAOException e) {
            logger.error("Error with client");
            throw new DAOException("ERROR! Don't found tours!");
        }
        return result;
    }


    public List<Tour> getAllHotTours(String tourType) throws DAOException
    {
        try{
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Tour> cq = cb.createQuery(Tour.class);
        Root<Tour> tourRoot = cq.from(Tour.class);
        cq.select(tourRoot);
        cq.where(cb.equal(tourRoot.get(Tour_.TOUR_TYPE), tourType), cb.equal(tourRoot.get(Tour_.HOT_TOUR), true));
        List<Tour> result = entityManager.createQuery(cq).getResultList();
    }
        catch (DAOException e) {
            logger.error("Error with client");
    throw new DAOException("ERROR! Don't found hot tours!");
}
        return result;
    }


}
