package dao;

import model.Offer;

import javax.ejb.Remote;
import java.util.List;

@Remote
public interface ClientDaoInterface 
{

    List<Offer> getClientInfo(int id);
}
