package dao;

import model.Tour;

import javax.ejb.Remote;
import java.util.List;

@Remote
public interface TourDaoInterface 
{
    List<Tour> getAllTours();
    List<Tour> getHotTours(String tourType);
}
