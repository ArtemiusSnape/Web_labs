package dao;

import model.Offer;

import javax.ejb.Remote;
import java.util.List;

@Remote
public interface BookingDaoInterface 
{

    void bookTour(int clientId, int tourId, int minAmountOfOffers, double discountValue);

}
