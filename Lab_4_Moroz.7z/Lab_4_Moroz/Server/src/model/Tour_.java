package model;

import javax.annotation.Generated;
import javax.persistence.metamodel.ListAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(Tour.class)
public abstract class Tour_ 
{
	public static volatile SingularAttribute<Tour, Integer> tourId;
	public static volatile SingularAttribute<Tour, String> tourType;
	public static volatile SingularAttribute<Tour, Boolean> hotTour;
	public static volatile ListAttribute<Tour, Offer> offers;
	public static volatile SingularAttribute<Tour, Double> tourPrice;

	public static final String TOUR_ID = "tourId";
	public static final String OFFERS = "offers";
	public static final String TOUR_TYPE = "tourType";
	public static final String HOT_TOUR = "hotTour";
	public static final String TOUR_PRICE = "tourPrice";

}

