package model;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(Offer.class)
public abstract class Offer_ 
{

	public static volatile SingularAttribute<Offer, Boolean> isPaid;
	public static volatile SingularAttribute<Offer, Integer> offerId;
	public static volatile SingularAttribute<Offer, Double> finalPrice;
	public static volatile SingularAttribute<Offer, Client> client;
	public static volatile SingularAttribute<Offer, Tour> tour;

	public static final String CLIENT = "client";
	public static final String IS_PAID = "isPaid";
	public static final String OFFER_ID = "offerId";
	public static final String FINAL_PRICE = "finalPrice";
	public static final String TOUR = "tour";

}

