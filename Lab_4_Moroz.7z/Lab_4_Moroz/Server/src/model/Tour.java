package model;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * @author Artsiom Maroz
 */
@Entity(name = "Tour")
@NamedQueries({
	
    @NamedQuery(
            name= "selectSpecificTours",
            query = "select t from Tour t where t.tourType = :type and t.hotTour=true"
    		),
        @NamedQuery(
                name= "selectAllTours",
                query = "select t from Tour t"),
        @NamedQuery(
                name= "getTour",
                query = "select t from Tour t where t.tourId = :id"
        )
})

public class Tour implements Serializable 
{
    /**
     * Tour id
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int tourId;

    private static Logger logger = LogManager.getLogger("logger");
    /**
     * Tour status
     */
    private boolean hotTour;
    
    /**
     * Tour type
     */
    private String tourType;

    /**
     * Tour price
     */
    private double tourPrice;

    /**
     * Constructor for tour
     * @param tourType
     * @param hotTour
     * @param tourPrice
     */
    public Tour(String tourType, boolean hotTour, double tourPrice) 
    {
        this.tourType = tourType;
        this.hotTour = hotTour;
        this.tourPrice = tourPrice;
        this.offers = new ArrayList<Offer>();
        logger.info("Create Tour);
    }

    /**
     * Adds new offer
     * @param offer
     */
    public void addOffer(Offer offer)
    {
        this.offers.add(offer);
    }

    /**
     * Offers connected with tour
     */
    @OneToMany(mappedBy = "tour", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    private List<Offer> offers;

    /**
     * Gets tour id
     * @return id
     */
    public int getTourId() 
    {
        return tourId;
    }

    /**
     * Sets tour id
     * @param tourId
     */
    public void setTourId(int tourId) 
    {
        this.tourId = tourId;
    }

    /**
     * Gets tour type
     * @return type
     */
    public String getTourType() 
    {
        return tourType;
    }

    /**
     * Sets tour type
     * @param tourType
     */
    public void setTourType(String tourType) 
    {
        this.tourType = tourType;
    }
    
    /**
     * Gets tour price
     * @return price
     */
    public double getTourPrice() 
    {
        return tourPrice;
    }

    /**
     * Sets tour price
     * @param tourPrice
     */
    public void setTourPrice(double tourPrice) 
    {
        this.tourPrice = tourPrice;
    }
    /**
     * Gets tour status
     * @return status
     */
    public boolean hotTour() 
    {
        return hotTour;
    }

    /**
     * Sets tour status
     * @param last_minute_tour
     */
    public void setLastHotTour(boolean hotTour) 
    {
        this.hotTour = hotTour;
    }

    @Override
    public String toString() 
    {
        return "Tour\n" + "tourId=" + tourId +
                "\ntourType='" + tourType + '\'' +
                "\nHotTour=" + HotTour + "\ntourPrice=" + tourPrice;
    }
}
