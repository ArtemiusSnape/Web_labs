package model;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * @author Artsiom Maroz
 */
@Entity(name = "Client")
@NamedQueries({
        @NamedQuery(
                name= "getClient",
                query = "select c from Client c where c.clientId = :id")
})
public class Client implements Serializable 
{
    private static Logger logger = LogManager.getLogger("logger");
    /**
     * Clients id
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int clientId;

    /**
     * Client name
     */
    private String name;

    @OneToMany(mappedBy = "client")
    private List<Offer> offers;

    /**
     * Constructor for client
     * @param name
     */
    public Client(String name) 
    {
        this.name = name;
        this.offers = new ArrayList<Offer>();
        logger.info("Create Client);
    }

    /**
     * Adds new offer to client
     * @param offer
     */
    public void addOffer(Offer offer)
    {
        this.offers.add(offer);
    }
    
    /**
     * Sets client id
     * @param clientId
     */
    public void setClientId(int clientId) 
    {
        this.clientId = clientId;
    }
    
    /**
     * Gets client id
     * @return id
     */
    public int getClientId() 
    {
        return clientId;
    }

    /**
     * Gets client name
     * @return name
     */
    public String getName() 
    {
        return name;
    }

    /**
     * Sets client name
     * @param name
     */
    public void setName(String name) 
    {
        this.name = name;
    }

    @Override
    public String toString() 
    {
        return "Client" + "\nclientId=" + clientId + "\nname='" + name + '\'';
    }
}
