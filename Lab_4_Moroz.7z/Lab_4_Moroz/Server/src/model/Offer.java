package model;

import javax.persistence.*;
import java.io.Serializable;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * @author Artsiom Maroz
 */
@Entity(name = "Offer")
@NamedQueries({
        @NamedQuery(
                name="selectClientInfo",
                query = "select o from Offer o where o.client.clientId = :id"),
        @NamedQuery(
                name="checkClientDiscount",
                query = "select count(o.offerId) from Offer o where o.client.clientId = :id  and o.isPaid = true"
        )
})
public class Offer implements Serializable {

    public static final String tourId = "tourId";
    public static final String clientId = "clientId";

    /**
     * Offer id
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int offerId;

    /**
     * Tour id
     */
    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = tourId,  nullable=false)
    private Tour tour;

    /**
     * Client id
     */
    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = clientId, nullable=false)
    private Client client;

    /**
     * Offer status
     */
    private boolean isPaid;

    /**
     * Tours final price
     */
    private double finalPrice;
    
    /**
     * Gets tour id
     * @return id
     */
    public static String getTourId() {
        return tourId;
    }

    private static Logger logger = LogManager.getLogger("logger");
    
    /**
     * Gets offer id
     * @return id
     */
    public int getOfferId() 
    {
        return offerId;
    }
    
    /**
     * Gets client id
     * @return id
     */
    public static String getClientId() 
    {
        return clientId;
    }
    
    /**
     * Gets tour
     * @return
     */
    public Tour getTour() 
    {
        return tour;
    }
    
    /**
     * Sets offer id
     * @param offerId
     */
    public void setOffer_id(int offerId) 
    {
        this.offerId = offerId;
    }

    /**
     * Sets tour
     * @param tour
     */
    public void setTour(Tour tour) 
    {
        this.tour = tour;
    }

    /**
     * Gets client
     * @return client
     */
    public Client getClient() 
    {
        return client;
    }

    /**
     * Constructor for tour
     * @param tour
     * @param client
     * @param isPaid
     * @param finalPrice
     */
    public Offer(Tour tour, Client client, boolean isPaid, double finalPrice) 
    {
        this.tour = tour;
        this.client = client;
        this.isPaid = isPaid;
        this.finalPrice = finalPrice;
        logger.info("Create Offer);
    }
    
    /**
     * Sets client
     * @param client
     */
    public void setClient(Client client) 
    {
        this.client = client;
    }
    
    /**
     * Sets offer status
     * @param isPaid
     */
    public void setIs_paid(boolean isPaid) 
    {
        this.isPaid = isPaid;
    }

    /**
     * Gets tour final price
     * @return price
     */
    public double getFinalPrice() 
    {
        return finalPrice;
    }
    
    /**
     * Gets offer status
     * @return status
     */
    public boolean isIsPaid() 
    {
        return isPaid;
    }

    /**
     * Sets tour final price
     * @param finalPrice
     */
    public void setFinalPrice(double finalPrice) 
    {
        this.finalPrice = finalPrice;
    }

    @Override
    public String toString() 
    {
        return "Offer" +
                "\nofferId=" + offerId +
                "\n" + tour +
                "\n" + client +
                "\nisPaid=" + isPaid +
                "\nfinalPrice=" + finalPrice;
    }
}
