package exceptions;

/**
 * Represents DAO exception
 * @author Artsiom Maroz
 */
public class DAOException extends Exception {

    /**
     * Constructor
     * @param message
     */
    public DAOException(String message)
    {
        super(message);
    }

    /**
     * Constructor
     * @param message
     * @param e
     */
    public DAOException(String message, Throwable e)
    {
        super(message, e);
    }

    @Override
    public String getMessage()
    {
        return super.getMessage();
    }

    @Override
    public void printStackTrace()
    {
        super.printStackTrace();
    }

}
